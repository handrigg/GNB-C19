#Program to process the GNB COVID-19 captions page
#References: https://cran.r-project.org/web/packages/tidytext/vignettes/tidytext.html 
#https://www.tidytextmining.com/sentiment.html
#Created by G. Handrigan in the fall of 2021
#Data presented at the NBHRF 2021 conference
#Questions, please contact GH

#load the required libraries
library(tuber) #to get access to the google/youtube API
library(youtubecaption) #function that grabs the captions from each video
library(readr)
library(purrr)
library(stringr)
library(dplyr)
library(tidytext) #unest_tokens
library(ggplot2)
library(tidyr)
library(textdata)
library(ggplot2)
library(scales)
library(lubridate)

#load the captions data
captions_cpac_df <- read.csv("vid_stats09222021.csv")

GNB_captions_df <- tibble(line = 1:171927, text = captions_cpac_df$text)

#tokenize the text (individual word per row)
GNB_captions_df <- GNB_captions_df %>%
  unnest_tokens(word, text)
#remove stop words
GNB_df <- GNB_captions_df %>%
  anti_join(get_stopwords())

#cleaning up a few errors or things that aren't relevant
GNB_df <- GNB_df %>% filter(!(word == "uh"))
GNB_df <- GNB_df %>% filter(!(word == "um"))
GNB_df <- GNB_df %>% filter(!(word == "music"))
GNB_df <- GNB_df %>% filter(!(word == "de"))

#####word frequency#####

#using count to find the most common words
GNB_df %>% 
  count(word, sort = TRUE)


GNB_df$word <- as.factor(GNB_df$word)

GNB_df_plot <- GNB_df %>%
  count(word, sort = TRUE) %>%
  filter(n > 900) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(n, word, fill = "#02488C")) +
  geom_col(fill ="#02488C") +
  labs(y = NULL)+
  theme(
    panel.background = element_rect(fill='transparent'), #transparent panel bg
    plot.background = element_rect(fill='transparent', color=NA), #transparent plot bg
    panel.grid.major = element_blank(), #remove major gridlines
    panel.grid.minor = element_blank(), #remove minor gridlines
    legend.background = element_rect(fill='transparent'), #transparent legend bg
    legend.box.background = element_rect(fill='transparent') #transparent legend panel
  )

p <- GNB_df_plot + labs(x = "Word frequency occurrence")

#ggsave("word_frequency_900.png", plot = p, width = 11, height = 8.5, units = "in", bg = "transparent")

#####sentiment analysis#####
positive <- get_sentiments("bing") %>%
  filter(sentiment == "positive")
negative <- get_sentiments("bing") %>%
  filter(sentiment == "negative")

GNB_captions_df %>%
  semi_join(positive) %>%
  count(word, sort = TRUE)

GNB_captions_df %>%
  semi_join(negative) %>%
  count(word, sort = TRUE)


bing <- get_sentiments("bing")

bing_word_counts <- GNB_captions_df %>%
  inner_join(bing) %>%
  count(word, sentiment, sort = TRUE)

bing_word_counts$sentiment <- as.factor(bing_word_counts$sentiment)
mycolors <- c("#E0A725", "#02488C")


s <- bing_word_counts %>%
  filter(n > 150) %>%
  mutate(n = ifelse(sentiment == "negative", -n, n)) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n, fill = sentiment)) +
  geom_col() +
  scale_fill_manual(values=mycolors)+
  coord_flip() +
  labs(y = "Contribution to sentiment")+
  labs(x = NULL)+
  theme(
    panel.background = element_rect(fill='transparent'), #transparent panel bg
    plot.background = element_rect(fill='transparent', color=NA), #transparent plot bg
    panel.grid.major = element_blank(), #remove major gridlines
    panel.grid.minor = element_blank(), #remove minor gridlines
    legend.background = element_rect(fill='transparent'), #transparent legend bg
    legend.box.background = element_rect(fill='transparent'), #transparent legend panel
    legend.position = "none"
  )

#ggsave("sentiment.png", plot = s, width = 11, height = 8.5, units = "in", bg = "transparent")


GNB_sentiment <- GNB_df %>%
  inner_join(get_sentiments("bing")) %>%
  count(index = line %/% 40, sentiment) %>%
  pivot_wider(names_from = sentiment, values_from = n, values_fill = 0) %>% 
  mutate(sentiment = positive - negative)

ggplot(GNB_sentiment, aes(index, sentiment)) +
  geom_col(show.legend = FALSE) 



#####wordclouds#####
library(reshape2)
library(wordcloud)
library(wordcloud2)
library(dplyr)

GNB_df %>%
  count(word) %>%
  with(wordcloud(word, n, max.words = 500))

word_freq_df <- bing_word_counts[ -c(2) ]




word_freq_df_pos <- select(filter(bing_word_counts, sentiment == "positive"),c(1,3))
word_freq_df_neg <- select(filter(bing_word_counts, sentiment == "negative"),c(1,3))

wordcloud2(data=word_freq_df_pos, size=1.6, color='random-dark')
wordcloud2(data=word_freq_df_neg, size=1.6, color='random-dark')


figPath = "Virus2.png"
wordcloud2(data=word_freq_df_neg, figPath = figPath, size=0.2, color='random-light')

letterCloud(data=word_freq_df_neg, word = "COVID-19", wordSize = 1)


####video timeline####
#From https://benalexkeen.com/creating-a-timeline-graphic-using-r-and-ggplot2/
#HSPP_01 colors - #02488C - #2B061E - #EOA725
playlist_df1 <-  get_playlist_items(filter =
                                      c(playlist_id = "PLdgoQ6C3ckQtiTzcMqw3r7leJ5xpagpcF"), max_results = 200, simplify = TRUE)


dates_df <- transform(playlist_df1, date = substr(contentDetails.videoPublishedAt, 1, 10))

dates_df$date <- as.Date(dates_df$date)

dates_df <- tidyr::separate(dates_df, date, c('year', 'month', 'day'), sep = "-",remove = FALSE)

dates_df$status <- 'analyzed'

write.csv(dates_df,"milestones.csv", row.names = FALSE)

dates_df <- read.csv('milestones.csv')

dates_df <- dates_df %>% mutate(milestone= 1:n())

status_levels <- c("analyzed", "not analyzed")
status_colors <- c("#02488C", "#E0A725")

dates_df$status <- factor(dates_df$status, levels=status_levels, ordered=TRUE)


positions <- c(0.5, -0.5, 1.0, -1.0, 1.5, -1.5)
directions <- c(1, -1)

line_pos <- data.frame(
  "date"=unique(dates_df$date),
  "position"=rep(positions, length.out=length(unique(dates_df$date))),
  "direction"=rep(directions, length.out=length(unique(dates_df$date)))
)

dates_df <- merge(x=dates_df, y=line_pos, by="date", all = TRUE)
dates_df <- dates_df[with(dates_df, order(date, status)), ]


text_offset <- 0.05
dates_df$month_count <- ave(dates_df$date==dates_df$date, dates_df$date, FUN=cumsum)
dates_df$text_position <- (dates_df$month_count * text_offset * dates_df$direction) + dates_df$position

month_buffer <- 2

dates_df$date <- as.Date(dates_df$date)

month_date_range <- seq(min(dates_df$date) - months(month_buffer), max(dates_df$date) + months(month_buffer), by='month')
month_format <- format(month_date_range, '%b')
month_df <- data.frame(month_date_range, month_format)

year_date_range <- seq(min(dates_df$date) - months(month_buffer), max(dates_df$date) + months(month_buffer), by='year')
year_date_range <- as.Date(
  intersect(
    ceiling_date(year_date_range, unit="year"),
    floor_date(year_date_range, unit="year")
  ),  origin = "1970-01-01"
)
year_format <- format(year_date_range, '%Y')
year_df <- data.frame(year_date_range, year_format)

timeline_plot<-ggplot(dates_df,aes(x=date,y=0, col=status, label=milestone))
timeline_plot<-timeline_plot+labs(col="Milestones")
timeline_plot<-timeline_plot+scale_color_manual(values=status_colors, labels=status_levels, drop = FALSE)
timeline_plot<-timeline_plot+theme_classic()

# Plot horizontal black line for timeline
timeline_plot<-timeline_plot+geom_hline(yintercept=0, 
                                        color = "black", size=0.3)

# Plot vertical segment lines for milestones
timeline_plot<-timeline_plot+geom_segment(data=dates_df[dates_df$month_count == 1,], aes(y=position,yend=0,xend=date), color='black', size=0.2)

# Plot scatter points at zero and date
timeline_plot<-timeline_plot+geom_point(aes(y=0), size=3)

# Don't show axes, appropriately position legend
timeline_plot<-timeline_plot+theme(axis.line.y=element_blank(),
                                   axis.text.y=element_blank(),
                                   axis.title.x=element_blank(),
                                   axis.title.y=element_blank(),
                                   axis.ticks.y=element_blank(),
                                   axis.text.x =element_blank(),
                                   axis.ticks.x =element_blank(),
                                   axis.line.x =element_blank(),
                                   legend.position = "bottom"
)

# Show text for each month
timeline_plot<-timeline_plot+geom_text(data=month_df, aes(x=month_date_range,y=-0.1,label=month_format),size=2.5,vjust=0.5, color='black', angle=90)
# Show year text
timeline_plot<-timeline_plot+geom_text(data=year_df, aes(x=year_date_range,y=-0.2,label=year_format, fontface="bold"),size=2.5, color='black')
# Show text for each milestone
timeline_plot<-timeline_plot+geom_text(aes(y=text_position,label=milestone),size=2.5)
print(timeline_plot)


#ggsave("timeline.png", width = 11, height = 8, units = "in")


####Manual search for missing terms####
filter(GNB_captions_df, !grepl("exercise",text))
filter(GNB_captions_df, !grepl("healthy eating",text))
filter(GNB_captions_df, !grepl("COPD",text))
filter(GNB_captions_df, !grepl("obesity",text))
filter(GNB_captions_df, !grepl("heart diseaese",text))


